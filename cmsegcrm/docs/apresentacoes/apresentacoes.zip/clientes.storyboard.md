# Storyboard — Módulo Clientes

> Roteiro cena-a-cena para gravar o vídeo explicativo deste módulo.
> Público-alvo: **Atendimento / Comercial**. Duração sugerida: **4–6 minutos**.

---

## Cena 1 — Abertura (0:00 – 0:20)
- **Tela:** card de abertura com o nome do módulo.
- **Narração:** "Olá! Neste vídeo vamos conhecer o módulo **Módulo Clientes** do CRM. Ele é voltado principalmente para a área de Atendimento / Comercial."
- **Ação:** mostrar logo/título.

## Cena 2 — Objetivo (0:20 – 0:50)
- **Tela:** slide "Objetivo".
- **Narração:** "Centralizar o cadastro de pessoas físicas e jurídicas, com histórico completo de apólices, propostas, comunicações e tarefas."
- **Ação:** destacar a frase-chave em tela.

## Cena 3 — Onde encontrar (0:50 – 1:20)
- **Tela:** dashboard do CRM, clicar no menu lateral em **Módulo Clientes**.
- **Narração:** "No menu lateral, acesse **Módulo Clientes**. Você verá a tela inicial do módulo."
- **Ação:** gravar o clique e a transição.

## Cena 4 — Telas principais (1:20 – 2:30)
- **Tela:** percorrer cada tela do módulo.
- **Narração:** "As principais telas são:"
  1. Listagem com busca por nome, CPF/CNPJ, telefone e e-mail
  2. Filtros por status, vendedor responsável e origem
  3. Ficha do cliente (/dashboard/clientes/[id]) com abas: dados, apólices, propostas, histórico, anexos
- **Ação:** mostrar cada uma rapidamente, com zoom nos detalhes.

## Cena 5 — Fluxos no dia a dia (2:30 – 4:00)
- **Tela:** demonstrar passo a passo.
- **Narração:** "No dia a dia, os fluxos mais comuns são:"
  1. Cadastrar novo cliente manualmente ou via importação
  2. Vincular cliente a uma cotação/proposta/apólice
  3. Registrar interações e tarefas a partir da ficha
- **Ação:** executar cada fluxo na tela real.

## Cena 6 — Campos importantes (4:00 – 4:40)
- **Tela:** formulário de cadastro/edição.
- **Narração:** "Atenção aos campos: Dados pessoais, Endereço, Contato, Vendedor responsável, Tags, Observações."
- **Ação:** destacar cada campo com um pequeno highlight.

## Cena 7 — Boas práticas (4:40 – 5:30)
- **Tela:** lista de dicas.
- **Narração:** "Algumas boas práticas que recomendamos:"
  - Sempre preencher CPF/CNPJ — chave de deduplicação
  - Usar tags para segmentar campanhas
  - Confirmar telefone/WhatsApp antes de salvar

## Cena 8 — Encerramento (5:30 – 6:00)
- **Tela:** slide final.
- **Narração:** "Esse foi o módulo **Módulo Clientes**. Qualquer dúvida, fale com a equipe responsável. Até o próximo vídeo!"
- **Ação:** card final com contato/suporte.

---

## Checklist de gravação
- [ ] Limpar dados sensíveis da tela (LGPD).
- [ ] Usar conta de demonstração, não conta real.
- [ ] Gravar em 1080p, microfone com pop filter.
- [ ] Cortar silêncios > 1s na edição.
- [ ] Incluir legenda em PT-BR.
